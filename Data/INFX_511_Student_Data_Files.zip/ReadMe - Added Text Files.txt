The following are some text copies of famous documents that I added for your use, if you want. Feel free to add your own. Be sure they are text files not PDF or Word documents.

DoI - US Declaration of Independence
BoR - US Original Bill ofRights
Bor-Full - US Bill of Rights with all Amendments
Gettysburg - US President Lincoln's Gettysburg Address
MagnaCarta - England 1215 (English translation)
Margaritaville - Lyrics by Jimmy Buffett
UDHR - UN The Universal Declaration of Human Rights
95Theses - Germany English translation of Martin Luther's �Disputation on the Power and Efficacy of Indulgences,� also known as �The 95 Theses,�